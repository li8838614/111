# VuRoyal
To find and order FDA approved drug

cd VuRoyal && git pull && mvn clean install -Dmaven.test.skip=true

nohup java -jar target/web-thymeleaf.jar --spring.profiles.active=cloud-deploy &

vYW3rK*R

分页：
https://frontbackend.com/thymeleaf/spring-boot-bootstrap-thymeleaf-pagination-jpa-liquibase-h2
=======
mySQLDB:
 ip: 34.152.21.73 port 3306 account root  p/w: vYW3rK*R
 dbname: vuroyaldb  table: vr_VRProudctListV1
 
 project team members:
    daniel daniel.chen.us@gmail.com
    tiger  tigerjsh@gmai.com
    Ryan   ...

test
