package com.eigpay.idf.system.controller.sys;

import org.junit.Test;

import java.util.Locale;

public class ResourceControllerTest {

    @Test
    public void list() {
        System.out.println(Locale.getDefault().toString());
    }

    @Test
    public void add() {

    }

    @Test
    public void save() {
    }
}