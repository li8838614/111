package com.eigpay.idf.system.utils;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;

public class PasswordUtilTest {

    @Test
    public void genDefaultPassword() {
        System.out.println(PasswordUtil.genDefaultPassword("VuRoyal"));

        Assert.assertTrue(PasswordEncoderFactories.createDelegatingPasswordEncoder()
                .matches("1","{bcrypt}$2a$10$n3dG0Rk6Hgn3WDWIld0uRuCU5.eNuPhuW.4yL8eDlhjr3BxYOvcUm"));

        Assert.assertTrue(PasswordEncoderFactories.createDelegatingPasswordEncoder()
                .matches("VuRoyal","{bcrypt}$2a$10$g8/TMh0b4bDce9v5cQK61.jihWS7LpRAFNXC9F7fopwn7fpe/tbWC"));
    }
}