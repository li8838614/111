"use strict";

window.onload = function() {
  editor = CodeMirror(document.getElementById("code"), {
    mode: "text/html",
    extraKeys: {"Ctrl-Space": "autocomplete"},
    value: document.documentElement.innerHTML
  });
};