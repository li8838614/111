package com.eigpay.idf.vuRoyal.domain.service;

import com.eigpay.idf.vuRoyal.domain.model.Order;
import com.eigpay.idf.vuRoyal.domain.model.OrderDto;
import com.eigpay.idf.vuRoyal.domain.port.incoming.ManageOrders;
import com.eigpay.idf.vuRoyal.domain.port.incoming.OrderGoods;
import com.eigpay.idf.vuRoyal.domain.port.outgoing.PagingAndSortingOrder;
import com.eigpay.idf.vuRoyal.domain.port.outgoing.PersistenceOrder;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;

import java.util.Date;

/**
 * @author shihujiang
 * @date 2022/2/28
 */
@Service
public class OrderService extends AbstractService implements OrderGoods, ManageOrders {

    private final PersistenceOrder persistenceOrder;

    private final PagingAndSortingOrder pagingAndSortingOrder;

    @Override
    public void order(OrderDto orderDto) {
        Order order = new Order();
        BeanUtils.copyProperties(orderDto, order, getNullPropertyNames(orderDto));
        order.setCustomerId(1L);
        order.setCreateTime(new Date());
        order.setSts(0);
        persistenceOrder.save(order);
    }

    @Override
    public Page<Order> page(OrderDto dto, int page, int size) {

        Order order = new Order();
        order.setCustomerName(StringUtils.defaultIfEmpty(StringUtils.trim(dto.getCustomerName()), null));
        order.setRemark(StringUtils.defaultIfEmpty(StringUtils.trim(dto.getRemark()), null));
        order.setPhone(StringUtils.defaultIfEmpty(StringUtils.trim(dto.getPhone()), null));
        order.setSts((ObjectUtils.isEmpty(dto.getSts()) || (-1 == dto.getSts())) ? null : dto.getSts());

        ExampleMatcher matcher = ExampleMatcher.matchingAny().withIgnoreNullValues()
                .withMatcher("remark", ExampleMatcher.GenericPropertyMatchers.contains())
                .withMatcher("sts", ExampleMatcher.GenericPropertyMatchers.contains())
                .withMatcher("phone", ExampleMatcher.GenericPropertyMatchers.contains())
                .withMatcher("email", ExampleMatcher.GenericPropertyMatchers.contains());
        return pagingAndSortingOrder.page(Example.of(order, matcher),
                PageRequest.of(page, size, Sort.by("createTime").descending().and(Sort.by("sts"))));
    }

    @Override
    public OrderDto getOrder(Long id) {
        OrderDto dto = new OrderDto();
        Order order = persistenceOrder.getOne(id);
        BeanUtils.copyProperties(order, dto);
        dto.setOrderId(order.getId());
        return dto;
    }

    @Override
    public Boolean uptOrder(OrderDto orderDto) {
        Order needToBeUpdatedOrder = persistenceOrder.findById(orderDto.getOrderId());
        BeanUtils.copyProperties(orderDto, needToBeUpdatedOrder, getNullPropertyNames(orderDto));
        return persistenceOrder.save(needToBeUpdatedOrder).getId() != null;
    }

    public OrderService(PersistenceOrder persistenceOrder, PagingAndSortingOrder pagingAndSortingOrder) {
        this.persistenceOrder = persistenceOrder;
        this.pagingAndSortingOrder = pagingAndSortingOrder;
    }
}
