package com.eigpay.idf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

/**
 * @author shihujiang
 * @date 2019-06-12
 */
@SpringBootApplication
@EnableCaching
@EnableJpaAuditing
public class IdfApplication {

    public static void main(String[] args) {
        SpringApplication.run(IdfApplication.class, args);
    }

}


