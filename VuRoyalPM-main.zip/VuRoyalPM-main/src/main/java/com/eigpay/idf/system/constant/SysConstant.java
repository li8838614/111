package com.eigpay.idf.system.constant;

/**
 * @author shihujiang
 * @date 2019-06-14
 */
public class SysConstant {

    public final static String ADMIN = "admin";
}
