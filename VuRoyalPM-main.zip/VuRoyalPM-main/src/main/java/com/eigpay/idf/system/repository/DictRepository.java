package com.eigpay.idf.system.repository;

import com.eigpay.idf.system.entity.Dict;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author shihujiang
 * @date 2019-07-30
 */
public interface DictRepository extends JpaRepository<Dict, Long> {
}
