package com.eigpay.idf.vuRoyal.domain.model;

import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author shihujiang
 * @date 2022/3/29
 */
@Data
public class OrderDto {

    private Long orderId;

    @NotBlank(message = "customer name not blank")
    private String customerName;

    @NotBlank(message = "phone not blank")
    private String phone;

    @NotBlank(message = "email not blank")
    private String email;

    private String remark;

    private Long productId;

    private Integer quantity;

    private Integer sts;

    private String owner;

    private String sourceName;

    private String notes;
}
