package com.eigpay.idf.system.service.VuRoyal;

import com.eigpay.idf.system.entity.VuRoyal.Product;
import com.eigpay.idf.system.service.base.BaseService;

/**
 * @author shihujiang
 * @date 2022/2/28
 */
public interface ProductService extends BaseService<Product> {
}
