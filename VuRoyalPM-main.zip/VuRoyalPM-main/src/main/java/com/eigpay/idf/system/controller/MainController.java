package com.eigpay.idf.system.controller;

import com.eigpay.idf.system.entity.SysUser;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.unbescape.html.HtmlEscape;

import javax.servlet.http.HttpServletRequest;
import java.util.Locale;

/**
 * Application home page and login.
 */

/**
 * @author shihujiang
 * @date 2019-06-12
 */
@Controller
public class MainController {

    private static final String VUROYRAL = "VuRoyral";

    @ModelAttribute("menuHref")
    public String module() {
        return "index";
    }

    @RequestMapping("/")
    public String root() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null) {
            return "redirect:/login.html";
        }

        if (auth instanceof AnonymousAuthenticationToken) {
            //return "redirect:/signin.html";
            return "redirect:/searchproduct";
        }


        SysUser user = (SysUser) auth.getPrincipal();
        if (VUROYRAL.equals(user.getUsername())) {
            return "redirect:/vuRoyral/index.html";
        }

        return "redirect:/index.html";
    }

    @GetMapping("/manage")
    public String manageIndex(){
        return "redirect:/vuRoyral/index.html";
    }

    /**
     * Home page.
     */
    @RequestMapping("/index.html")
    public String index() {
        return "index";
    }

    /**
     * VuRoyral zone index.
     */
    @RequestMapping("/vuRoyral/index.html")
    public String vuRoyralIndex() {
        return "redirect:/manage/vr/order";
    }

    /**
     * User zone index.
     */
    @RequestMapping("/user/index.html")
    public String userIndex() {
        return "user/index";
    }

    /**
     * Administration zone index.
     */
    @RequestMapping("/admin/index.html")
    public String adminIndex() {
        return "admin/index";
    }

    /**
     * Shared zone index.
     */
    @RequestMapping("/shared/index.html")
    public String sharedIndex() {
        return "shared/index";
    }

    /**
     * Login vo.
     */
    @RequestMapping("/login.html")
    public String login() {
        return "login";
    }

    /**
     * Login vo with error.
     */
    @RequestMapping("/login-error.html")
    public String loginError(Model model) {
        model.addAttribute("loginError", true);
        return "login";
    }

    /**
     * Simulation of an exception.
     */
    @RequestMapping("/simulateError.html")
    public void simulateError() {
        throw new RuntimeException("This is a simulated error message");
    }

    /**
     * Error page.
     */
    @RequestMapping("/error.html")
    public String error(HttpServletRequest request, Model model) {
        model.addAttribute("errorCode", "Error " + request.getAttribute("javax.servlet.error.status_code"));
        Throwable throwable = (Throwable) request.getAttribute("javax.servlet.error.exception");
        StringBuilder errorMessage = new StringBuilder();
        errorMessage.append("<ul>");
        while (throwable != null) {
            errorMessage.append("<li>").append(HtmlEscape.escapeHtml5(throwable.getMessage())).append("</li>");
            throwable = throwable.getCause();
        }
        errorMessage.append("</ul>");
        model.addAttribute("errorMessage", errorMessage.toString());
        return "error";
    }

    /**
     * Error page.
     */
    @RequestMapping("/403.html")
    public String forbidden() {
        return "403";
    }


}
