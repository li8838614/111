package com.eigpay.idf.vuRoyal.domain.port.incoming;

import com.eigpay.idf.vuRoyal.domain.model.Order;
import com.eigpay.idf.vuRoyal.domain.model.OrderDto;
import org.springframework.data.domain.Page;

/**
 * 管理订单
 *
 * @author shihujiang
 * @date 2022/4/7
 */
public interface ManageOrders {

    /**
     * 订单分页
     *
     * @param searchCriteria 搜索条件
     * @param page           第几页
     * @param size           每页数量
     * @return 分页数据
     */
    Page<Order> page(OrderDto searchCriteria, int page, int size);

    /**
     * get order
     *
     * @param id order id
     * @return order
     */
    OrderDto getOrder(Long id);

    /**
     * update order
     *
     * @param orderDto order dto
     * @return boolean
     */
    Boolean uptOrder(OrderDto orderDto);
}
