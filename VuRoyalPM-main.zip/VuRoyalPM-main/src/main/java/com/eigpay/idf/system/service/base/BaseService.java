package com.eigpay.idf.system.service.base;

import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

/**
 * @author shihujiang
 * @date 2019-08-01
 */
public interface BaseService<E> {

    /**
     * get by primary key.
     *
     * @param id primary id.
     * @return Obj.
     */
    E get(Long id);

    /**
     * Get list.
     *
     * @param query conditions
     * @return objects.
     */
    List<E> list(E query);

    /**
     * page list
     *
     * @param pageable pageable
     * @return lists
     */
    Page<E> list(Pageable pageable);

    /**
     * find all
     *
     * @param example  query conditions
     * @param pageable page conditions
     * @return Pgae
     */
    Page<E> findAll(Example<E> example, Pageable pageable);

    /**
     * save entity.
     *
     * @param entity entity
     */
    void saveOrUpt(E entity);

    /**
     * delete .
     *
     * @param id obj id.
     */
    void delete(Long id);
}