package com.eigpay.idf.system.service.sys;

import com.eigpay.idf.system.entity.SysResource;
import com.eigpay.idf.system.service.base.BaseService;

import java.util.List;

/**
 * @author shihujiang
 * @date 2019-07-10
 */
public interface ResourceService extends BaseService<SysResource> {

    /**
     * 查询特定用户的资源
     *
     * @param userId user id.
     * @return resources.
     */
    List<SysResource> resources(Long userId);

    /**
     * 资源列表.根据前端模版展示需要重排的资源列表.
     *
     * @return menu list.
     */
    List<SysResource> allResources();


    /**
     * get user permissions.
     *
     * @param userId user id.
     * @return permissions.
     */
    List<String> getPermissions(Long userId);

}
