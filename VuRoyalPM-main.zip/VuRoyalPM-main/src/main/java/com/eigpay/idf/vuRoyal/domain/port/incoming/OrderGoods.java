package com.eigpay.idf.vuRoyal.domain.port.incoming;

import com.eigpay.idf.vuRoyal.domain.model.OrderDto;

/**
 * 订购商品
 *
 * @author shihujiang
 */
public interface OrderGoods {

    /**
     * 客户订购
     *
     * @param orderDto
     */
    void order(OrderDto orderDto);
}
