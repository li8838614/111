package com.eigpay.idf.system.controller.VuRoyal;

import com.eigpay.idf.system.controller.BaseController;
import com.eigpay.idf.system.controller.VuRoyal.vo.ProductVo;
import com.eigpay.idf.system.entity.VuRoyal.Product;
import com.eigpay.idf.system.service.VuRoyal.ProductService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * 产品
 *
 * @author shihujiang
 * @date 2022/2/28
 */
@Controller
@RequestMapping("/searchproduct")
public class ProductsController extends BaseController<ProductVo, Product> {

    private static final String LIST_VIEW_NAME = "VuRoyal/product/list";
    private static final String CATEGORY_NEW = "new";
    private static final String CATEGORY_TOP = "top";
    private static final String CATEGORY_WEEK = "week";

    public ProductService productService;

    public ProductsController(ProductService productService) {
        this.productService = productService;
    }

    @RequestMapping
    public String list(Model model, ProductVo productVo,
                       @RequestParam(defaultValue = "9") String version,
                       @RequestParam(defaultValue = "") String category,
                       @RequestParam(defaultValue = "0") int page,
                       @RequestParam(defaultValue = "10") int size) {

        Product query = new Product();

        query.setNdc(StringUtils.defaultIfEmpty(StringUtils.trim(productVo.getNumber()), null));
        query.setGenericName(StringUtils.defaultIfEmpty(StringUtils.trim(productVo.getNumber()), null));
        query.setStrength(StringUtils.defaultIfEmpty(StringUtils.trim(productVo.getNumber()), null));
        query.setVrBriefName(StringUtils.defaultIfEmpty(StringUtils.trim(productVo.getNumber()), null));
        categoryDeal(query, category);


        ExampleMatcher matcher = ExampleMatcher.matchingAny().withIgnoreNullValues()
                .withMatcher("genericName", ExampleMatcher.GenericPropertyMatchers.contains())
                .withMatcher("ndc", ExampleMatcher.GenericPropertyMatchers.contains())
                .withMatcher("productName", ExampleMatcher.GenericPropertyMatchers.contains())
                .withMatcher("vrBriefName", ExampleMatcher.GenericPropertyMatchers.contains())
                .withMatcher("topList", ExampleMatcher.GenericPropertyMatchers.contains())
                .withMatcher("productOfWeek", ExampleMatcher.GenericPropertyMatchers.contains())
                .withMatcher("fdaNew", ExampleMatcher.GenericPropertyMatchers.contains())
                ;

        Page<Product> pageList = productService.findAll(Example.of(query, matcher), PageRequest.of(page, size));
        model.addAttribute("page", pageList);
        model.addAttribute("productVo", productVo);

        return LIST_VIEW_NAME + version;

    }

    /**
     * deal category
     *
     * @param product  product
     * @param category category  new-FDA newly Approved;
     *                 week-Products of the week;
     *                 top-Top 20 List;
     */
    private void categoryDeal(Product product, String category) {
        if (StringUtils.isEmpty(category)) {
            return;
        }

        if (CATEGORY_NEW.equals(category)) {
            product.setFdaNew(Boolean.TRUE);
        }

        if (CATEGORY_TOP.equals(category)) {
            product.setTopList(Boolean.TRUE);
        }
        if (CATEGORY_WEEK.equals(category)) {
            product.setProductOfWeek(Boolean.TRUE);
        }
    }

}
