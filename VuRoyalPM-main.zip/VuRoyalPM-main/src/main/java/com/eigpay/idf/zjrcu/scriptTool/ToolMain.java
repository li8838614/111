package com.eigpay.idf.zjrcu.scriptTool;

import com.eigpay.idf.system.entity.SysUser;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @author shihujiang
 * @date 2022/3/25
 */
@Controller
@RequestMapping("/script/tool")
public class ToolMain {

    private static final String ADD_VIEW_NAME = "zjrcu/tool/add.html";
    private static final String UPDATE_VIEW_NAME = "zjrcu/tool/update.html";
    private static final String LIST_VIEW_NAME = "zjrcu/tool/list.html";

    @GetMapping
    public String home(Model model) {
        model.addAttribute("obj", new SysUser());
        return ADD_VIEW_NAME;
    }


}
