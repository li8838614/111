package com.eigpay.idf.system.service.sys;

import com.eigpay.idf.system.controller.login.SignupForm;
import com.eigpay.idf.system.entity.SysUser;
import com.eigpay.idf.system.exception.PasswordsMatchException;
import com.eigpay.idf.system.exception.SignupException;
import com.eigpay.idf.system.exception.UsernameExistsException;
import com.eigpay.idf.system.repository.UserRepository;
import com.eigpay.idf.system.service.base.BaseServiceImpl;
import com.eigpay.idf.system.utils.PasswordUtil;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author shihujiang
 * @date 2019-06-13
 */
@Service
public class UserServiceImpl
        extends BaseServiceImpl<UserRepository, SysUser> implements UserService {

//    private UserRepository userRepository;


    @Override
    public List<SysUser> list(SysUser query) {
        SysUser user = new SysUser();

        return super.list(query);
    }

    @Override
    public SysUser getUserByUsername(String username) {
        return repository.findByUsername(username);
    }


    public UserServiceImpl(UserRepository userRepository) {
        super(userRepository);
//        this.userRepository = userRepository;
    }

    @Override
    public void signUp(SignupForm signupForm) throws SignupException {

        // 1.Compare password and rePassword
        if (!matchPassword(signupForm.getPassword(), signupForm.getRePassword())) {
            throw new PasswordsMatchException("password not match.");
        }

        // 2.Check username
        if (isUsernameExits(signupForm.getEmail())) {
            throw new UsernameExistsException("username already exits.");
        }

        SysUser user = new SysUser(signupForm.getEmail(), PasswordUtil.genDefaultPassword(signupForm.getPassword()));
        repository.save(user);
    }


    /**
     * Is username exits.
     *
     * @param username username
     * @return return true if username exits.
     */
    private boolean isUsernameExits(String username) {
        return repository.findByUsername(username) != null;
    }

    /**
     * match password
     *
     * @param password   password
     * @param rePassword re password
     * @return match or not.
     */
    private boolean matchPassword(String password, String rePassword) {

        if ("".equals(password) || "".equals(rePassword)) {
            return false;
        }

        return password.equals(rePassword);

    }
}
