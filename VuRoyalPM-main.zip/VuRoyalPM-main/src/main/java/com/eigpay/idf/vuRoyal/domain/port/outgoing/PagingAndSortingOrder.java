package com.eigpay.idf.vuRoyal.domain.port.outgoing;

import com.eigpay.idf.vuRoyal.domain.model.Order;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

/**
 * @author shihujiang
 * @date 2022/4/7
 */
public interface PagingAndSortingOrder {

    /**
     * 分页
     *
     * @param example  查询条件
     * @param pageable 分页条件
     * @return 分页数据
     */
    Page<Order> page(Example<Order> example, Pageable pageable);

}
