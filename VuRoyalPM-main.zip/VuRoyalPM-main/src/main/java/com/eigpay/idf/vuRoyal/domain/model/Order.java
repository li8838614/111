package com.eigpay.idf.vuRoyal.domain.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.*;
import java.util.Date;

/**
 * @author shihujiang
 * @date 2022/3/29
 */
@DynamicUpdate
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "vr_order")
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long customerId;

    private String customerName;

    private String phone;

    private String email;

    private String remark;

    private Long productId;

    private Integer quantity;

    private Date createTime;

    private Integer sts;

    private String sourceName;

    private String owner;

    private String notes;

}
