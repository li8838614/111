package com.eigpay.idf.system.service.sys;

import com.eigpay.idf.system.entity.Institution;
import com.eigpay.idf.system.service.base.BaseService;

/**
 * @author shihujiang
 * @date 2019-07-30
 */
public interface InstitutionService extends BaseService<Institution> {

}
