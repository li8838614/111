package com.eigpay.idf.system.entity.VuRoyal;

import lombok.Data;

import javax.persistence.*;

/**
 * @author shihujiang
 * @date 2022/2/28
 */
@Data
@Entity
@Table(name = "vr_products_list_v2")
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "vrid")
    public Long vrId;

    public String rxOtcSchedule;

    public String genericName;

    public String productName;

    public String route;

    public String strength;

    public String dosageForm;

    public String labeler;

    public String marketStatus;

    public String productImage;

    public String ndc;

    public String howSupplied;

    public String vrBriefName;

    public String awp;

    /**
     * Top 20 List
     */
    public Boolean topList;

    /**
     * Products of the week
     */
    public Boolean productOfWeek;

    /**
     * FDA newly Approved
     */
    public Boolean fdaNew;

}
