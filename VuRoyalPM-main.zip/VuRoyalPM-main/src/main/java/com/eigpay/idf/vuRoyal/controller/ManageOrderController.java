package com.eigpay.idf.vuRoyal.controller;

import com.eigpay.idf.vuRoyal.domain.model.OrderDto;
import com.eigpay.idf.vuRoyal.domain.port.incoming.ManageOrders;
import com.eigpay.idf.vuRoyal.domain.port.incoming.OrderGoods;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
 * @author shihujiang
 * @date 2022/3/29
 */
@Controller
@RequestMapping("/manage/vr/order")
public class ManageOrderController {

    private static final String LIST_VIEW_NAME = "VuRoyal/order/vrOrderList";
    private static final String UPDATE_VIEW_NAME = "VuRoyal/order/vrOrderUpdate";

    ManageOrders manageOrders;

    @GetMapping
    public String manageOrders(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            Model model, OrderDto dto) {

        model.addAttribute("page", manageOrders.page(dto, page, size));
        model.addAttribute("qc", dto);
        return LIST_VIEW_NAME;
    }

    @GetMapping("/{id}")
    public String jumpTpUpdatePage(@PathVariable Long id, Model model) {
        model.addAttribute("addOrUpt", "upt");
        model.addAttribute("order", manageOrders.getOrder(id));
        return UPDATE_VIEW_NAME;
    }

    @ResponseBody
    @PostMapping
    public ResponseEntity<?> uptOrder(@Valid @RequestBody OrderDto orderDto) {
        manageOrders.uptOrder(orderDto);
        return ResponseEntity.ok().build();
    }

    public ManageOrderController(ManageOrders manageOrders) {
        this.manageOrders = manageOrders;
    }


}
