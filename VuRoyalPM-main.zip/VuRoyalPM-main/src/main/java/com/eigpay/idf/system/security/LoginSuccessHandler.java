package com.eigpay.idf.system.security;

import com.eigpay.idf.system.constant.SysConstant;
import com.eigpay.idf.system.controller.sys.vo.MenuVo;
import com.eigpay.idf.system.entity.SysUser;
import com.eigpay.idf.system.service.sys.ResourceService;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.SavedRequestAwareAuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @author shihujiang
 * @date 2019-07-11
 */
@Component
public class LoginSuccessHandler extends SavedRequestAwareAuthenticationSuccessHandler {

    private ResourceService resourceService;

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication) throws IOException, ServletException {

        System.out.println("login success. loading allResources." + resourceService);
        SysUser user = (SysUser) authentication.getPrincipal();
        Set<GrantedAuthority> authorities = new HashSet<>();
        // Admin has full access.
        if (user.getUsername().equals(SysConstant.ADMIN)) {
            user.setMenus(new MenuVo().conversionMenuVo(resourceService.allResources()));
            authorities.add(new SimpleGrantedAuthority("*:*"));
            authorities.add(new SimpleGrantedAuthority("ROLE_ADMIN"));
        } else {
            user.setMenus(new MenuVo().conversionMenuVo(resourceService.resources(user.getId())));
            // 获取当前用户的权限信息.权限标识符规则[资源标识符:操作:对象实例ID]
            List<String> permissions = resourceService.getPermissions(user.getId());
            for (String permission : permissions) {
                authorities.add(new SimpleGrantedAuthority(permission));
            }
            authorities.add(new SimpleGrantedAuthority("ROLE_USER"));
        }

        user.setAuthorities(authorities);

        updateAuthentication(authentication, user);

        super.onAuthenticationSuccess(request, response, authentication);

    }

    public LoginSuccessHandler(ResourceService resourceService) {
        this.resourceService = resourceService;
    }

    private void updateAuthentication(Authentication authentication, Object principal) {
        UsernamePasswordAuthenticationToken token = (UsernamePasswordAuthenticationToken) authentication;
        Authentication newAuthentication = new UsernamePasswordAuthenticationToken(principal, token.getCredentials(), token.getAuthorities());
        SecurityContextHolder.getContext().setAuthentication(newAuthentication);
    }
}
