package com.eigpay.idf.vuRoyal.domain.port.outgoing;

import com.eigpay.idf.vuRoyal.domain.model.Order;

import java.util.Optional;

/**
 * @author shihujiang
 */
public interface PersistenceOrder {

    /**
     * 持久化订单
     *
     * @param order order
     * @return order
     */
    Order save(Order order);

    /**
     * get order by lazy
     *
     * @param id order id
     * @return order
     */
    Order getOne(Long id);

    /**
     * find by id.
     * 立即执行数据库查询
     *
     * @param id id
     * @return order
     */
    Order findById(Long id);
}
