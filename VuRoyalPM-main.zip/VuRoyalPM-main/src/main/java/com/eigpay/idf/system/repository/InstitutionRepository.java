package com.eigpay.idf.system.repository;

import com.eigpay.idf.system.entity.Institution;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author shihujiang
 * @date 2019-07-30
 */
public interface InstitutionRepository extends JpaRepository<Institution, Long> {
}
