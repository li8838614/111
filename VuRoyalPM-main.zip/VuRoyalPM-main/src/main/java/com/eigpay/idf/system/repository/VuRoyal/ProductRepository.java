package com.eigpay.idf.system.repository.VuRoyal;

import com.eigpay.idf.system.entity.VuRoyal.Product;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author shihujiang
 * @date 2022/2/28
 */
public interface ProductRepository extends JpaRepository<Product, Long> {

}
