package com.eigpay.idf.system.controller.VuRoyal.vo;

import lombok.Data;

/**
 * @author shihujiang
 * @date 2022/2/28
 */
@Data
public class ProductVo {

   public String searchKey;

   public String number;
}
