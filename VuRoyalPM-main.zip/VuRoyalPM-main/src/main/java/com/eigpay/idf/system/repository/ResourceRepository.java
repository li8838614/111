package com.eigpay.idf.system.repository;

import com.eigpay.idf.system.entity.SysResource;
import com.eigpay.idf.system.entity.SysUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

/**
 * @author shihujiang
 * @date 2019-07-10
 */
public interface ResourceRepository extends JpaRepository<SysResource, Long> {

    /**
     * get user's resource
     *
     * @param userId user id
     * @return resources
     */
    @Query(
            value = "select * from idf_sys_resource res left JOIN  idf_sys_role_res_rel rel  on res.id = rel.resource_id where rel.role_id in (" +
                    "select urr.role_id from idf_sys_user_role_rel urr LEFT JOIN idf_sys_role role on urr.role_id=role.id where urr.user_id=?1)",
            nativeQuery = true)
    List<SysResource> getByUser(Long userId);


}
