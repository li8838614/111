package com.eigpay.idf.system.service.sys;

import com.eigpay.idf.system.controller.login.SignupForm;
import com.eigpay.idf.system.entity.SysUser;
import com.eigpay.idf.system.exception.SignupException;
import com.eigpay.idf.system.service.base.BaseService;

/**
 * @author shihujiang
 * @date 2019-06-13
 */
public interface UserService extends BaseService<SysUser> {






    /**
     * get user by username.
     *
     * @param username username
     * @return user object.
     */
    SysUser getUserByUsername(String username);


    /**
     * User sign up.
     *
     * @param signupForm sign up object
     * @return user object.
     * @throws SignupException  se.
     */
    void signUp(SignupForm signupForm) throws SignupException;

}
