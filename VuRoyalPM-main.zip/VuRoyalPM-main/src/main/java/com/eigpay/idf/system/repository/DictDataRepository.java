package com.eigpay.idf.system.repository;

import com.eigpay.idf.system.entity.DictData;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * @author shihujiang
 * @date 2019-07-30
 */
public interface DictDataRepository extends JpaRepository<DictData, Long> {

    /**
     * get dict data .
     *
     * @param code code.
     * @return dict data.
     */
    List<DictData> getDictDataByCode(String code);
}
