package com.eigpay.idf.system.utils;

import lombok.Getter;
import org.tmatesoft.svn.core.SVNException;
import org.tmatesoft.svn.core.SVNNodeKind;
import org.tmatesoft.svn.core.SVNURL;
import org.tmatesoft.svn.core.auth.ISVNAuthenticationManager;
import org.tmatesoft.svn.core.io.SVNRepository;
import org.tmatesoft.svn.core.io.SVNRepositoryFactory;
import org.tmatesoft.svn.core.wc.SVNWCUtil;

/**
 * SVN kit util
 *
 * @author shihujiang
 * @date 2020/4/16
 */
@Getter
public class SvnKitUtil {

    private String userName;

    private String password;

    private String svnUrl;

    private static SVNRepository svnRepository = null;

    public SvnKitUtil(String userName, String password, String svnUrl) {
        this.userName = userName;
        this.password = password;
        this.svnUrl = svnUrl;
    }

    public SVNRepository authSvn() throws SVNException {
        svnRepository = SVNRepositoryFactory.create(SVNURL.parseURIEncoded(this.svnUrl));
        svnRepository.setAuthenticationManager(createDefaultAuthenticationManager());
        return svnRepository;
    }

    public boolean urlExist() throws SVNException {
        SVNNodeKind nodeKind = svnRepository.checkPath("", -1);
        return nodeKind != SVNNodeKind.NONE;

    }

    private ISVNAuthenticationManager createDefaultAuthenticationManager() {
        return SVNWCUtil.createDefaultAuthenticationManager(this.userName, this.password);
    }
}
