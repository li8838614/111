package com.eigpay.idf.vuRoyal.controller;

import com.eigpay.idf.vuRoyal.domain.model.OrderDto;
import com.eigpay.idf.vuRoyal.domain.port.incoming.OrderGoods;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.validation.Valid;

/**
 * @author shihujiang
 * @date 2022/3/29
 */
@Controller
@RequestMapping("/api/vr/order")
public class OrderController {

    OrderGoods orderGoods;

    @ResponseBody
    @PostMapping
    public ResponseEntity<?> orderGoods(@Valid @RequestBody OrderDto orderDto) {
        orderGoods.order(orderDto);
        return ResponseEntity.ok().build();
    }

    public OrderController(OrderGoods orderGoods) {
        this.orderGoods = orderGoods;
    }


}
