package com.eigpay.idf.system.controller;

import com.eigpay.idf.system.controller.sys.vo.InstitutionForm;
import com.eigpay.idf.system.utils.SvnKitUtil;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.tmatesoft.svn.core.SVNAuthenticationException;
import org.tmatesoft.svn.core.SVNException;
import org.tmatesoft.svn.core.io.SVNRepository;

import java.util.ArrayList;
import java.util.List;

/**
 * @author shihujiang
 * @date 2020/4/16
 */
@Controller
public class SvnController {


    @GetMapping("/svn")
    public String index(Model model){
        InstitutionForm form = new InstitutionForm();
        form.setPid(1L);
        model.addAttribute("addOrUpt", "add");
        model.addAttribute("obj", form);
        return "svn/add";
    }

    public void print(String userName, String password, String svnUrl, String svnFilePath) {

        List<String> paths = readFromText(svnFilePath);

        if (paths == null || paths.size() <= 0) {
            return;
        }

        SvnKitUtil svnKitUtil = new SvnKitUtil(userName, password, svnUrl);
        try {
            SVNRepository svnRepository = svnKitUtil.authSvn();
        } catch (SVNException e) {
            System.out.println("auth svn exception.");
        }


        for (String path : paths) {
            try {
                if (svnKitUtil.urlExist()) {
                    System.out.println(path + "exist.");
                } else {
                    System.out.println(path + "not exist.");
                }
            } catch (SVNException e) {
                if (e instanceof SVNAuthenticationException) {
                    System.out.println("您没有权限访问" + path);
                }
            }
        }

    }


    private List<String> readFromText(String svnFilePaths) {
        List<String> paths = new ArrayList<>();
        paths.add("https://211.159.165.197/svn/rjht/20170307citicguoanbn/doc/18验收文档/03北京中心/验收文档");
        paths.add("https://211.159.165.197/svn/rjht/20170307citicguoanbn/doc/18验收文档/03北京中心/验收文档3");
        return paths;
    }

}
