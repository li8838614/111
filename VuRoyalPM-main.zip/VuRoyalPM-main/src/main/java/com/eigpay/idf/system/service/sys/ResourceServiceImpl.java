package com.eigpay.idf.system.service.sys;

import com.eigpay.idf.system.entity.SysResource;
import com.eigpay.idf.system.repository.ResourceRepository;
import com.eigpay.idf.system.service.base.BaseServiceImpl;
import com.eigpay.idf.system.utils.MenuUtil;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * @author shihujiang
 * @date 2019-07-10
 */
@Service
public class ResourceServiceImpl
        extends BaseServiceImpl<ResourceRepository, SysResource> implements ResourceService {

    ResourceRepository resourceRepository;

    private static final List<SysResource> rearrangeList = new ArrayList<>();

    public ResourceServiceImpl(ResourceRepository resourceRepository) {
        super(resourceRepository);
        this.resourceRepository = resourceRepository;
    }


    @Cacheable(value = "sysUserCache", key = "#userId")
    @Override
    public List<SysResource> resources(Long userId) {
        return resourceRepository.getByUser(userId);
    }


    @Override
    public List<String> getPermissions(Long userId) {
        List<String> permissions = new ArrayList<>();

        List<SysResource> resources = resources(userId);
        for (SysResource sysResource : CollectionUtils.emptyIfNull(resources)) {
            if (!StringUtils.isEmpty(sysResource.getPermission())){
                permissions.add(sysResource.getPermission());
            }
        }
        return permissions;
    }


    @Override
    public List<SysResource> allResources() {
        List<SysResource> resourceList = repository.findAll();

        // 重排菜单以符合页面展示需要,需要实现深度优先遍历
        SysResource rootNode = new SysResource();
        rootNode.setId(0L);
        rearrangeList.clear();
        return depthFirstSearch(resourceList, rootNode);
    }

    private List<SysResource> depthFirstSearch(List<SysResource> nodes, SysResource node) {

        for (SysResource n : MenuUtil.allChildNode(nodes, node.getId())) {
            rearrangeList.add(n);
            depthFirstSearch(nodes, n);
        }

        return rearrangeList;
    }


}
