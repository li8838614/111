package com.eigpay.idf.vuRoyal.infrastructure.adapter;

import com.eigpay.idf.system.entity.VuRoyal.Product;
import com.eigpay.idf.vuRoyal.domain.model.Order;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author shihujiang
 * @date 2022/2/28
 */
public interface SpringDataOrderRepository extends JpaRepository<Order, Long> {

}
