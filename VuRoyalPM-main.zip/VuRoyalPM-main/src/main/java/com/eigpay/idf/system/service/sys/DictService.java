package com.eigpay.idf.system.service.sys;

import com.eigpay.idf.system.entity.Dict;
import com.eigpay.idf.system.entity.DictData;
import com.eigpay.idf.system.service.base.BaseService;

import java.util.List;

/**
 * @author shihujiang
 * @date 2019-08-01
 */
public interface DictService extends BaseService<Dict> {


    /**
     * Get dictionary data by code.
     *
     * @param code dict unique code.
     * @return
     */
    List<DictData> getDataByDictCode(String code);


    /**
     * save dict data.
     *
     * @param dictData dict data.
     */
    void saveDictData(DictData dictData);


    /**
     * delete dict data by id.
     *
     * @param id dict data id.
     */
    void deleteDictData(Long id);


}
