package com.eigpay.idf.system.service.VuRoyal;

import com.eigpay.idf.system.entity.VuRoyal.Product;
import com.eigpay.idf.system.repository.VuRoyal.ProductRepository;
import com.eigpay.idf.system.service.base.BaseServiceImpl;
import org.springframework.stereotype.Service;

/**
 * @author shihujiang
 * @date 2022/2/28
 */
@Service
public class ProductServiceImpl extends BaseServiceImpl<ProductRepository, Product> implements ProductService {

    public ProductServiceImpl(ProductRepository repository) {
        super(repository);
    }
}
