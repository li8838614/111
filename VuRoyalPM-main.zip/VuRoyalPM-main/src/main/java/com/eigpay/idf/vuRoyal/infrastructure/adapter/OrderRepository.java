package com.eigpay.idf.vuRoyal.infrastructure.adapter;

import com.eigpay.idf.vuRoyal.domain.model.Order;
import com.eigpay.idf.vuRoyal.domain.port.outgoing.PagingAndSortingOrder;
import com.eigpay.idf.vuRoyal.domain.port.outgoing.PersistenceOrder;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

/**
 * @author shihujiang
 * @date 2022/3/29
 */
@Component
public class OrderRepository implements PersistenceOrder, PagingAndSortingOrder {

    private final SpringDataOrderRepository springDataOrderRepository;

    public OrderRepository(SpringDataOrderRepository springDataOrderRepository) {
        this.springDataOrderRepository = springDataOrderRepository;
    }

    @Override
    public Order save(Order order) {
        return springDataOrderRepository.save(order);
    }

    @Override
    public Page<Order> page(Example<Order> example, Pageable pageable) {
        return springDataOrderRepository.findAll(example, pageable);
    }

    @Override
    public Order getOne(Long id) {
        return springDataOrderRepository.getOne(id);
    }

    @Override
    public Order findById(Long id) {
        return springDataOrderRepository.findById(id).orElse(null);
    }
}
